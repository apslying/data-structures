
public interface Lists {
	//all lists include add, delete, and display objects
	public void addObj();
	public void deleteObj();
	public void displayObj();

}
