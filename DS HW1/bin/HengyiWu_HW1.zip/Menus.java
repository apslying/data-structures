
public interface Menus {
	public void displayMenu();

}
