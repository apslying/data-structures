
public class Node{
		public Customer data;
		public Node next;
		
		public Node() {
		} 	
	}