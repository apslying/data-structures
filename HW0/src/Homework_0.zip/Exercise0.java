
public class Exercise0 {

	public static void main(String[] args) {
		System.out.println("Hengyi");
		System.out.println("Economics");

	}

}
