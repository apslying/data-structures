
public class Exercise2 {

	public static void main(String[] args) {
		System.out.println("A B C");
		System.out.println("1 5 9");
		System.out.println("8 7 9");
		System.out.println("1 6 0");
		System.out.println("1 7 9");

	}

}
