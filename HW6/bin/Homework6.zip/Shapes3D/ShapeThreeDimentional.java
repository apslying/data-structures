package Shapes3D;

public interface ShapeThreeDimentional {
	public double getShapeArea();
	public double getShapeVolume();
	public void printShapeInformation();
}
