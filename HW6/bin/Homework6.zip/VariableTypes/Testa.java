package VariableTypes;

public class Testa {
	
	public Testa(){
		
	}
	
	private int a;
	int b;
	protected int c;
	public int d;
	
	//The variables are declared in this class. Naturally all of them can be accessed. 
	public void printVariables(){
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}

}
