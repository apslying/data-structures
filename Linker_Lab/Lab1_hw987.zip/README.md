How to compile and run:

I have provided two .java files (linker.java and filereader.java).

Make sure these two files and your input text files are all in the same directory.

1. Open Terminal and cd to that directory.
2. Enter the command javac linker.java.
3. Enter the command java linker.
4. The program will prompt you to enter the name of the input text file. Enter it in the form input-1.txt.

That’s it. 